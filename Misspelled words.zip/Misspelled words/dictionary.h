#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#ifndef DICTIONARY_H
#define DICTIONARY_H

// maximum length for a word
// (e.g., pneumonoultramicroscopicsilicovolcanoconiosis)
#define LENGTH 45

/**
 * Returns true if word is in dictionary else false.
 */
int check(const char* word);

/**
 * Loads dictionary into memory.  Returns true if successful else false.
 */
int load(const char* dictionary);

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void);

/**
 * Unloads dictionary from memory.  Returns true if successful else false.
 */
int unload(void);

// typedef
typedef struct node
{
	char * val;
	struct node * next;
}node_t;

node_t * node_at_begin(node_t *  , char * );
node_t * make_sllist(char * );
void print_all(node_t * );


#endif // DICTIONARY_H
