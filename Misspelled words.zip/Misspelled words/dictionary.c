#include "dictionary.h"



//global var
node_t * arr[27];
int size_of_loaded=0;


/**
 * Returns 1  if word is in dictionary else 0.
 */
node_t * node_at_begin(node_t * head1 , char * val)
{
	node_t * newnode1 = malloc(sizeof(node_t));
	newnode1->val=val;
	newnode1->next=head1;
	head1=newnode1;
	return head1 ;
}
node_t * make_sllist(char * first_val)
{
	node_t * newnode = malloc(sizeof(node_t));
	newnode->val=first_val;
	newnode->next=NULL;
	return newnode ;
}
void print_all(node_t * crawler)
{
	printf("\n");
	while(crawler !=NULL)
	{
		printf("%s ,",crawler->val);
		crawler=crawler->next;
	}
}

int  check(const char* word)
{
    // TODO


	// ** convert word to lower case
	char lowercase_word[LENGTH+1];
	strcpy(lowercase_word , word);
	int len = strlen(lowercase_word);
	for(int i=0;i<len ;i++)
		lowercase_word[i]=tolower(lowercase_word[i]);
	// ** converted to lower case

	node_t * crawler = arr[lowercase_word[0]-'a']; // crawler is pointing to head of sllist
	while(crawler != NULL)
	{
		if(!strcmp(crawler->val , lowercase_word)) // if equal :
			return 1; // word founded

		crawler=crawler->next;

	}

    return 0; //not found !!
}

/**
 * Loads dictionary into memory.  Returns 1 if successful else 0.
 */
int  load(const char* dictionary)
{
    // TODO


	for(int i=0;i<27;i++)
		arr[i]=NULL;

	char * str;

	FILE * fp = fopen (dictionary,"r");
	if(fp == NULL)
		return 0; // cannot load the dictionary

	while(!feof(fp))
	{
		str= malloc( sizeof(char)* (LENGTH +1 ));
		fscanf(fp,"%s",str);
		if(isalpha(str[0]))
		{
			size_of_loaded++;

			if(arr[str[0]-'a']== NULL)
			{
				arr[str[0]-'a']=make_sllist(str);
			}
			else
			{
				arr[str[0]-'a']=node_at_begin(arr[str[0]-'a'] ,str);
			}
		}

	}

//	unload();


/* *** print all of dictionary

	for(int i=0;i<26;i++)
		if(arr[i]!=NULL)
		{
			printf("\n%c: ",'A'+i);
			print_all(arr[i]);
		}

*/
	fclose(fp);
    return 1;
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    // TODO
    return size_of_loaded;
}

/**
 * Unloads dictionary from memory.  Returns 1 if successful else 0.
 */
int unload(void)
{
    // TODO
	node_t * crawler1 ;
	node_t * crawler2 ;

	for(int i=0 ; i<27 ; i++)
	{
		crawler2=arr[i];

		while(crawler2 != NULL)
		{
			crawler1=crawler2;
			crawler2=crawler2->next ;
			free(crawler1);
		}
		arr[i]=NULL;
	}
    return 1;
}
