#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

// make a new type!!!
typedef uint8_t binary;

int main(void)
{
		//some commands that might be usefull
		//FILE* fp = fopen("card.raw", "r");
		//fread(buffer, 512, 1, fp);
		//sprintf(filename, "%03d.jpg", jpgcount);
		//outp = fopen(filename, "w");
		//fwrite(buffer, sizeof(buffer), 1, outp);

	FILE* fp = fopen("card.raw", "r");

	//definig buffer

	binary buffer[512];



    int jpgcount=0;





    //FILE* outp;
    

      




	while(!feof(fp))
	{
		FILE* outp;
		

		fread(buffer, 512, 1, fp);


		
			
			
		
		if (buffer[0]==0xff && buffer[1]==0xd8 && buffer[2]==0xff && (buffer[3]==0xe0 || buffer[3]==0xe1))
		{
			
			{
				fclose(outp);
				
				
			}

			

			
			char filename[8];
			sprintf(filename, "%03d.jpg", jpgcount);
			jpgcount++;
			
         outp = fopen(filename, "w");
		 fwrite(&buffer[0], 512*sizeof(binary), 1, outp);

		}
		


		else
		{
			fwrite(&buffer[0],512*sizeof(binary),1,outp);
		}

		
	
		
	}




	    fclose(fp);
		return 0;
}
