/**
 * generate.c
 *
 * Generates pseudorandom numbers in [0,LIMIT), one per line.
 *
 * Usage: generate n [s]
 *
 * where n is number of pseudorandom numbers to print
 * and s is an optional seed
 */
 
#define _XOPEN_SOURCE

#include "cs50.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// constant
#define LIMIT 65536

int main(int argc, string argv[])
{
    // TODO: agar tedad string ha ke dar 'cmd' be onvane 'command line argument' vared mikonim 0 ta (yani faghat main ra minevisim) ya bozorgtar mosavi ba 3 ta string bashad,barname dar haminja stop mishavad.pas baraye edame yaftane barname,bad az 'make',bayad 1 ya 2 ta string vared konim vagar na "usage.." ptint mishavad va barname payan miyabad.
    if (argc != 2 && argc != 3)
    {
        printf("Usage: generate n [s]\n");
        return 1;
    }

    // TODO: agar avalin string (argv[1])adad ya 'int' bashad, dar n rikhte mishavad vali agar string adad nabashad(masalan 'character' bashad) 'n'barabar ba "0" mishavad. 
    int n = atoi(argv[1]);


    // TODO:baraye inke 'drand48' tarif shavad,aval,'srand48' ra tarif mikonim.
    //hala agar 'argc=3' bashad,functione 'srand48' ba arguments '(long int)' va 'atoi(argv[2])' seda zade mishavad.(to call a function)
    //agar 'argc != 3' yani agar 'argc == 2' ,function 'srand48' ba arguments '(long int)' va 'atoi(argv[2])'' seda zade mishavad.(to call a function)
    // function 'srand48' dar har bar RUN shodan,adaad tasadofi motafaveti  ba dafe pish midahad.

    if (argc == 3)
    {
        srand48((long int) atoi(argv[2]));
    }
    else
    {
        srand48((long int) time(NULL));
    }

    // TODO: 'n' bar  meghdare 'drand48' ra dar sabet 'LIMIT'(=65536) zarb mikonad.va meghdar 'int'(sahih) an ra chap mikonad (float nist).
    // function 'drand48' dar har bar RUN shodan,adaad tasadofii dar bazeye [0.0 , 1.0) midahad.ke dar inja zarbdar adade bozorge "LIMIT" mishavad pas hasel,baz ham adade bozorgi ast.
    // ghabl az taarife 'drand48', function 'srand48' ya 'seed48' bayad taafif shavand.va adade "48" b yani in function ha az '48 bit intiger arithmatic'(48 bit fazaye RAM) estefade mikonand.
    for (int i = 0; i < n; i++)
    {
        printf("%i\n", (int) (drand48() * LIMIT));
    }

    // success
    return 0;
}
